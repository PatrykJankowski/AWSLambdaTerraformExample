def lambda_handler(event, context):
    return "Lambda is working!"
